package com.andrecnf.android.laserblast;

/**
 * Created by Bruno Alves on 28/03/2018.
 */

public class Player {

    /*Fields*/
    private int id, score;
    private String name;
    private String password;
    //String email;
    private boolean isDead;
    //Coordinates coordinate;
    //Orientation orientation;

    /* Constructors */
    public Player(int id_, String name_){
        id = id_;
        name = name_;
        isDead = false;
        score = 0;
    }

    public Player(int id_, String name_, String password_){
        id = id_;
        name = name_;
        password = password_;
        isDead = false;
        score = 0;
    }

    public int getId (){
        return this.id;
    }

    public String getName(){
        return this.name;
    }

    protected String getPassword(){
        return this.password;
    }

    public int getScore(){
        return this.score;
    }

    public boolean isDead(){
        return this.isDead;
    }

}
