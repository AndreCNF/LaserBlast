package com.andrecnf.android.laserblast;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.content.Intent;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {

    private Button button_play;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        button_play = (Button) findViewById(R.id.button_play);
        button_play.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //if (v.getId() == R.id.button_play)
                EditText name = (EditText) findViewById(R.id.TFusername);
                String str = name.getText().toString();
                //get the list of users in the game from the firebase
                /* if the username has alredy been chosen ask for another username
                Toast.makeText(LoginActivity.this, "Sorry, that username is already taken. Please choose another one", Toast.LENGTH_SHORT).show();
                */
                openMainActivity(str);

            }
        });
    }

    public void openMainActivity(String str) {
        Intent intent = new Intent(this, MainActivity.class);
        intent.putExtra("Username",str);
        startActivity(intent);
    }
}
